using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Linq;
using WebApplication_Shvenk_Sherbakov.Data;
using WebApplication_Shvenk_Sherbakov.Models;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace WebApplication_Shvenk_Sherbakov.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly ApplicationDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public string Login { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public IndexModel(ILogger<IndexModel> logger, ApplicationDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            var user = _context.Users.FirstOrDefault(u => u.Login == Login);

            if (user != null)
            {
                var hashedPassword = HashPassword(Password);

                if (string.IsNullOrEmpty(user.HashedPassword))
                {
                    user.HashedPassword = HashPassword(user.Password);
                    _context.SaveChanges();
                }

                if (user.HashedPassword == hashedPassword)
                {
                    _httpContextAccessor.HttpContext.Session.SetInt32("User_ID", user.ID_User);
                    if (user.Role == 1) // ���� ����������
                    {
                        return RedirectToPage("/ModeratorPage");
                    }
                    else // ���� ������������
                    {
                        return RedirectToPage("/HomePage");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "������������ ����� ��� ������.");
                    return Page();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "������������ ����� ��� ������.");
                return Page();
            }
        }

        public static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                var builder = new StringBuilder();
                foreach (var b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
