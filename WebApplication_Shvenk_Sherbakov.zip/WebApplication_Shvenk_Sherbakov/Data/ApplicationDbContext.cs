﻿using Microsoft.EntityFrameworkCore;
using WebApplication_Shvenk_Sherbakov.Models;

namespace WebApplication_Shvenk_Sherbakov.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        public DbSet<User> Users { get; set; }
        public DbSet<Goods> Goods { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasKey(u => u.ID_User);

            modelBuilder.Entity<Goods>()
                .HasKey(g => g.ID_Goods);

            modelBuilder.Entity<Order>()
                .HasKey(o => o.ID_Order);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.User_ID);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Goods)
                .WithMany(g => g.Orders)
                .HasForeignKey(o => o.Goods_ID);
        }
    }
}
