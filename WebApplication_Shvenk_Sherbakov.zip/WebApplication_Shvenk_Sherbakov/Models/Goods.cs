﻿namespace WebApplication_Shvenk_Sherbakov.Models
{
    public class Goods
    {
        public int ID_Goods { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool In_Stock { get; set; }
        public ICollection<Order> Orders { get; set; }
    }
}
