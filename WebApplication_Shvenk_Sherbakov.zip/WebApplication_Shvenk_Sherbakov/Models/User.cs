﻿namespace WebApplication_Shvenk_Sherbakov.Models
{
    public class User
    {
        public int ID_User { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string? HashedPassword { get; set; }
        public int Role { get; set; }
        public ICollection<Order> Orders { get; set; }
    }
}
