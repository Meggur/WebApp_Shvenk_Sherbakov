﻿namespace WebApplication_Shvenk_Sherbakov.Models
{
    public class Order
    {
        public int ID_Order { get; set; }
        public int User_ID { get; set; }
        public int Goods_ID { get; set; }
        public int Count { get; set; }
        public User User { get; set; }
        public Goods Goods { get; set; }
    }
}
